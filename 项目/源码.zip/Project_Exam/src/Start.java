import javax.swing.*;


/**
 * 程序入口
 * @author 金卓远
 */
public class Start {
    public static void main(String[] args) throws UnsupportedLookAndFeelException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        AnalyseFile w1 = new AnalyseFile();
        w1.setVisible(true);
    }
}
